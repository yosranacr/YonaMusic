export class Venue {
    constructor(
        public id: number,
        public name: string,
        public city: string,
        public country: string,
        public lat: number,
        public lng: number) { }
  }
  